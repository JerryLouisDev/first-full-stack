// config/database.js
module.exports = {

    'url' : 'mongodb+srv://demo:demo@cluster0.v11xd.mongodb.net/loversnotes?retryWrites=true&w=majority', 
    'dbName': 'loversnotes'
};
